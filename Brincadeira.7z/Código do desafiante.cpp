#include<iostream>
#include<stdio.h>
using namespace std;
int main() {
	int *d, m, in, x, N, D;
	do {
		cin >> N >> D;
		d = new int[N];
		if ( (N != 0) && (D != 0) )			cin >> x;
		for (int i = N - 1; i >= 0; i--) { //SEPARA O NUMERO EM UNIDADES E JOGA CADA UNIDADE DO N�MERO EM UM VETOR
			d[i] = x % 10;
			x = x / 10;
		}
		for (int i = 0; i < D; i++) { //MARCA OS 'D' MENORES N�MEROS PARA N�O SEREM EXIBIDOS
			m = 100;
			for (int a = 0; a < N; a++) {
				for (int b = 0; b < N; b++) {
					if (m >  d[b]) {
						m = d[b];
						in = b;
					}
				}
			}
			d[in] = 999;//MARCA��O DOS MENORES PS.: PP BAYTOLA
		}
		for (int a = 0; a < N; a++) {
			if (d[a] != 999) cout << d[a];
		}
		cout << endl;//BIRLLLLL
	}
	while ( (N != 0) && (D != 0) );	getchar();
	return 0;//MANDA SUA QUEST�O AGORA PRA GENTE TIAR O MONSTRO DA JAULA
}
