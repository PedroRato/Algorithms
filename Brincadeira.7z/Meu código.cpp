#include <bits/stdc++.h>
int main() {
    std::vector <std::pair <int, bool>> vet;
    int D;
    std::pair <int, int> menor, maior = {-1e10, 0};
    {   std::string num;
        char c;
        int deleta;
        const char *converte = &c;
        std::cin >> deleta >> D;     if((deleta+D) == 0) return EXIT_SUCCESS;
        std::cin >> num;
        for(auto i : num) {
            c = i;              //< caso nao usasse essa var, iria pegar os valores daquela pos ate o fim
            vet.push_back(std::make_pair(atoi(converte), true));
            if(vet[vet.size() -1].first > maior.first) {
                maior.first = vet[vet.size() -1].first;
                maior.second = vet.size() - 1;
            }
        }
    }
    while(D--) {
        menor = maior;
        for(int i = 0; i < vet.size(); i++) {
            if(vet[i].second and vet[i].first < menor.first){
                vet[menor.second].second = true;
                vet[i].second = false;
                menor.second = i;
                menor.first = vet[i].first;
            }
        }
    }
    for(auto i : vet) if(i.second) std::cout << i.first;  std::cout << "\n";
    return 0;
}
